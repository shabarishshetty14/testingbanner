/* -----------------------------
   UI Controls: Create and Manage Image Blocks + Text Blocks
   (With filename-based ids & inline rename in Layers)
------------------------------ */

/**
 * createControlBlock(index)
 * - Creates the UI controls for an image
 * - Keeps imageList array in sync
 * - Calls renderLayers() to update the Layers tree
 */
function createControlBlock(index) {
  const controls = document.getElementById('controls');

  // temporary base id; will be replaced on file upload with sanitized filename
  const baseId = `img${index + 1}`;

  const wrapper = document.createElement('div');
  wrapper.classList.add('image-block');
  wrapper.dataset.imgId = baseId;
  wrapper.innerHTML = `
    <strong>Image ${index + 1}</strong>
    <input type="file" class="imageUpload" accept="image/*" />
    <span class="fileNameDisplay" style="font-size: 13px; color: #555; margin-left: 8px;"></span><br />
    <div class="coords">
      <label>X: <input type="number" class="posX" value="0" /></label>
      <label>Y: <input type="number" class="posY" value="0" /></label>
    </div>
    Width: <input type="number" class="imgWidth" value="100" />
    Opacity: <input type="number" class="opacity" step="0.1" value="1" />
    Scale: <input type="number" class="scale" step="0.1" value="1" />
    Position (Time): <input type="number" class="delay" step="0.1" value="0" /> <br />
    <label><input type="checkbox" class="breakpoint"> <i class="fa-solid fa-circle-minus"></i> Breakpoint</label><br />
    <label><input type="checkbox" class="lockPosition"> <i class="fa-solid fa-lock"></i> Lock Position</label><br>
    <button class="addExtraAnim">+ Add Extra Animation</button>
    <div class="extra-anims"></div>
  `;
  controls.appendChild(wrapper);

  const imageData = {
    id: baseId,
    type: 'image',
    layerName: '',
    visible: true,

    fileName: '',
    src: '',
    x: 0, y: 0,
    width: 100,
    height: 'auto',
    opacity: 1,
    delay: 0,
    scale: 1,
    extraAnims: [],
    previewImg: null,
    breakpoint: false,
    locked: false,
    wrapper
  };

  imageList.push(imageData);

  // Select this block when clicked
  wrapper.addEventListener('click', () => {
    activeDragTarget = { imgData: imageData, animIndex: null };
    highlightPreview(imageData.id);
    highlightExtraAnim(wrapper, null);
    updatePreviewAndCode();
    renderLayers();
  });

  // Update data when inputs change
  const updateFromInputs = () => {
    imageData.x = parseInt(wrapper.querySelector('.posX').value) || 0;
    imageData.y = parseInt(wrapper.querySelector('.posY').value) || 0;
    imageData.width = parseInt(wrapper.querySelector('.imgWidth').value) || 100;
    imageData.height = 'auto';
    imageData.opacity = parseFloat(wrapper.querySelector('.opacity').value) || 0;
    imageData.scale = parseFloat(wrapper.querySelector('.scale').value) || 1;
    imageData.delay = parseFloat(wrapper.querySelector('.delay').value) || 0;
    imageData.breakpoint = wrapper.querySelector('.breakpoint').checked;
    imageData.locked = wrapper.querySelector('.lockPosition').checked;

    wrapper.querySelector('.posX').disabled = imageData.locked;
    wrapper.querySelector('.posY').disabled = imageData.locked;

    updatePreviewAndCode();
    renderLayers();
  };

  // Attach input handlers
  wrapper.querySelectorAll('input').forEach(input => {
    input.addEventListener('input', updateFromInputs);
  });
  const breakpointInput = wrapper.querySelector('.breakpoint');
  if (breakpointInput) breakpointInput.addEventListener('change', updateFromInputs);

  // Extra animations container
  const extraContainer = wrapper.querySelector('.extra-anims');

  // Add extra animation
  wrapper.querySelector('.addExtraAnim').addEventListener('click', (e) => {
    e.stopPropagation();
    const animIndex = imageData.extraAnims.length;
    const anim = { id: `${imageData.id}_anim_${animIndex}`, x: 0, y: 0, opacity: 1, delay: 1, scale: 1, locked: false };

    // Lock previous animations
    imageData.extraAnims.forEach((prevAnim, i) => {
      prevAnim.locked = true;
      const prevDiv = wrapper.querySelectorAll('.extra-anims .exit-controls')[i];
      if (prevDiv) {
        const lockBox = prevDiv.querySelector('.lockExtraAnim');
        const xInput = prevDiv.querySelector('.animX');
        const yInput = prevDiv.querySelector('.animY');
        if (lockBox) lockBox.checked = true;
        if (xInput) xInput.disabled = true;
        if (yInput) yInput.disabled = true;
      }
    });

    imageData.extraAnims.push(anim);

    // Lock base image
    imageData.locked = true;
    wrapper.querySelector('.lockPosition').checked = true;
    wrapper.querySelector('.posX').disabled = true;
    wrapper.querySelector('.posY').disabled = true;

    const animDiv = document.createElement('div');
    animDiv.classList.add('exit-controls');
    animDiv.innerHTML = `
      <strong>Extra Animation ${animIndex + 1}</strong><br />
      X: <input type="number" class="animX" value="0" />
      Y: <input type="number" class="animY" value="0" />
      Opacity: <input type="number" class="animOpacity" step="0.1" value="1" />
      Scale: <input type="number" class="animScale" step="0.1" value="1" />
      Position (Time): <input type="number" class="animDelay" step="0.1" value="1" /> <br />
      <label><input type="checkbox" class="lockExtraAnim"> <i class="fa-solid fa-lock"></i> Lock Animation</label> <br />
      <button class="removeAnim">Remove</button>
    `;
    extraContainer.appendChild(animDiv);

    // Click to select this extra animation
    animDiv.addEventListener('click', (ev) => {
      ev.stopPropagation();
      activeDragTarget = { imgData: imageData, animIndex: animIndex };
      highlightPreview(imageData.id);
      highlightExtraAnim(wrapper, animIndex);
      updatePreviewAndCode();
      renderLayers();
    });

    // Update animation inputs
    const updateAnim = () => {
      anim.locked = !!animDiv.querySelector('.lockExtraAnim').checked;
      animDiv.querySelector('.animX').disabled = anim.locked;
      animDiv.querySelector('.animY').disabled = anim.locked;
      anim.delay = parseFloat(animDiv.querySelector('.animDelay').value) || 0;
      anim.x = parseFloat(animDiv.querySelector('.animX').value) || 0;
      anim.y = parseFloat(animDiv.querySelector('.animY').value) || 0;
      anim.opacity = parseFloat(animDiv.querySelector('.animOpacity').value) || 0;
      anim.scale = parseFloat(animDiv.querySelector('.animScale').value) || 1;
      updatePreviewAndCode();
      renderLayers();
    };

    animDiv.querySelectorAll('input').forEach(input => input.addEventListener('input', updateAnim));
    const lockExtra = animDiv.querySelector('.lockExtraAnim');
    if (lockExtra) lockExtra.addEventListener('change', updateAnim);

    // Remove animation
    animDiv.querySelector('.removeAnim').addEventListener('click', (ev) => {
      ev.stopPropagation();
      const removed = imageData.extraAnims.splice(animIndex, 1);
      if (removed) {
        extraContainer.removeChild(animDiv);
        rebuildExtraAnimBlocks(wrapper, imageData);
        updatePreviewAndCode();
        renderLayers();
      }
    });

    updatePreviewAndCode();
    renderLayers();
  });

  // File upload handler (set id from filename)
  const fileInput = wrapper.querySelector('.imageUpload');
  fileInput.addEventListener('change', function (e) {
    const file = e.target.files[0];
    if (!file) return;

    wrapper.querySelector('.fileNameDisplay').textContent = file.name;

    const reader = new FileReader();
    reader.onload = function (event) {
      imageData.src = event.target.result;
      imageData.fileName = file.name;

      // determine id from filename (sanitize & ensure unique)
      const sanitized = sanitizeId(file.name);
      const unique = ensureUniqueId(sanitized);

      // centralized update of id across model and DOM
      setElementId(imageData, unique);

      // Remove old preview image if present
      if (imageData.previewImg && imageData.previewImg.parentNode === previewArea) {
        previewArea.removeChild(imageData.previewImg);
      }

      // Create new preview img element
      const img = document.createElement('img');
      img.src = imageData.src;
      img.classList.add('preview');
      img.id = imageData.id;
      previewArea.appendChild(img);
      imageData.previewImg = img;

      updatePreviewAndCode();
      renderLayers();
    };
    reader.readAsDataURL(file);
  });
}

/* -------------------------------------------------------
   Text control block (new)
   - fields: text content, font size, color, X/Y, opacity, scale, delay
--------------------------------------------------------- */
function createTextControlBlock(index) {
  const controls = document.getElementById('controls');

  // initial candidate id
  const baseId = `text${index + 1}`;

  const wrapper = document.createElement('div');
  wrapper.classList.add('image-block', 'text-block');
  wrapper.dataset.imgId = baseId;
  wrapper.innerHTML = `
    <strong>Text ${index + 1}</strong>
    <div style="margin-top:8px;">
      <textarea class="textContent" rows="2" placeholder="Enter text..."></textarea>
    </div>
    <div style="margin-top:8px;">
      <label>Font Size: <input type="number" class="fontSize" value="14" /></label>
      <label>Color: <input type="color" class="fontColor" value="#000000" /></label>
    </div>

    <div class="coords" style="margin-top:8px;">
      <label>X: <input type="number" class="posX" value="0" /></label>
      <label>Y: <input type="number" class="posY" value="0" /></label>
    </div>

    Opacity: <input type="number" class="opacity" step="0.1" value="1" />
    Scale: <input type="number" class="scale" step="0.1" value="1" />
    Position (Time): <input type="number" class="delay" step="0.1" value="0" /> <br />

    <label><input type="checkbox" class="breakpoint"> <i class="fa-solid fa-circle-minus"></i> Breakpoint</label><br />
    <label><input type="checkbox" class="lockPosition"> <i class="fa-solid fa-lock"></i> Lock Position</label><br>

    <button class="addExtraAnim">+ Add Extra Animation</button>
    <div class="extra-anims"></div>
  `;
  controls.appendChild(wrapper);

  const textData = {
    id: baseId,
    type: 'text',
    layerName: '',
    visible: true,

    text: '',
    fontFamily: 'Arial, sans-serif',
    fontSize: 14,
    color: '#000000',

    x: 0, y: 0,
    width: 'auto', height: 'auto',
    opacity: 1,
    scale: 1,
    delay: 0,
    extraAnims: [],
    previewImg: null, // will be DOM node for text
    breakpoint: false,
    locked: false,
    wrapper
  };

  imageList.push(textData);

  // Select this block when clicked
  wrapper.addEventListener('click', () => {
    activeDragTarget = { imgData: textData, animIndex: null };
    highlightPreview(textData.id);
    highlightExtraAnim(wrapper, null);
    updatePreviewAndCode();
    renderLayers();
  });

  const updateFromInputs = () => {
    textData.text = wrapper.querySelector('.textContent').value || '';
    textData.fontSize = parseInt(wrapper.querySelector('.fontSize').value) || 14;
    textData.color = wrapper.querySelector('.fontColor').value || '#000000';
    textData.x = parseInt(wrapper.querySelector('.posX').value) || 0;
    textData.y = parseInt(wrapper.querySelector('.posY').value) || 0;
    textData.opacity = parseFloat(wrapper.querySelector('.opacity').value) || 1;
    textData.scale = parseFloat(wrapper.querySelector('.scale').value) || 1;
    textData.delay = parseFloat(wrapper.querySelector('.delay').value) || 0;
    textData.breakpoint = wrapper.querySelector('.breakpoint').checked;
    textData.locked = wrapper.querySelector('.lockPosition').checked;

    wrapper.querySelector('.posX').disabled = textData.locked;
    wrapper.querySelector('.posY').disabled = textData.locked;

    updatePreviewAndCode();
    renderLayers();
  };

  wrapper.querySelectorAll('input, textarea').forEach(input => input.addEventListener('input', updateFromInputs));
  const bp = wrapper.querySelector('.breakpoint');
  if (bp) bp.addEventListener('change', updateFromInputs);

  // Extra animations container (same behavior)
  const extraContainer = wrapper.querySelector('.extra-anims');

  wrapper.querySelector('.addExtraAnim').addEventListener('click', (e) => {
    e.stopPropagation();
    const animIndex = textData.extraAnims.length;
    const anim = { id: `${textData.id}_anim_${animIndex}`, x: 0, y: 0, opacity: 1, delay: 1, scale: 1, locked: false };

    textData.extraAnims.forEach((prevAnim, i) => {
      prevAnim.locked = true;
      const prevDiv = wrapper.querySelectorAll('.extra-anims .exit-controls')[i];
      if (prevDiv) {
        const lockBox = prevDiv.querySelector('.lockExtraAnim');
        const xInput = prevDiv.querySelector('.animX');
        const yInput = prevDiv.querySelector('.animY');
        if (lockBox) lockBox.checked = true;
        if (xInput) xInput.disabled = true;
        if (yInput) yInput.disabled = true;
      }
    });

    textData.extraAnims.push(anim);
    textData.locked = true;
    wrapper.querySelector('.lockPosition').checked = true;
    wrapper.querySelector('.posX').disabled = true;
    wrapper.querySelector('.posY').disabled = true;

    const animDiv = document.createElement('div');
    animDiv.classList.add('exit-controls');
    animDiv.innerHTML = `
      <strong>Extra Animation ${animIndex + 1}</strong><br />
      X: <input type="number" class="animX" value="0" />
      Y: <input type="number" class="animY" value="0" />
      Opacity: <input type="number" class="animOpacity" step="0.1" value="1" />
      Scale: <input type="number" class="animScale" step="0.1" value="1" />
      Position (Time): <input type="number" class="animDelay" step="0.1" value="1" /> <br />
      <label><input type="checkbox" class="lockExtraAnim"> <i class="fa-solid fa-lock"></i> Lock Animation</label> <br />
      <button class="removeAnim">Remove</button>
    `;
    extraContainer.appendChild(animDiv);

    animDiv.addEventListener('click', (ev) => {
      ev.stopPropagation();
      activeDragTarget = { imgData: textData, animIndex: animIndex };
      highlightPreview(textData.id);
      highlightExtraAnim(wrapper, animIndex);
      updatePreviewAndCode();
      renderLayers();
    });

    const updateAnim = () => {
      anim.locked = !!animDiv.querySelector('.lockExtraAnim').checked;
      animDiv.querySelector('.animX').disabled = anim.locked;
      animDiv.querySelector('.animY').disabled = anim.locked;
      anim.delay = parseFloat(animDiv.querySelector('.animDelay').value) || 0;
      anim.x = parseFloat(animDiv.querySelector('.animX').value) || 0;
      anim.y = parseFloat(animDiv.querySelector('.animY').value) || 0;
      anim.opacity = parseFloat(animDiv.querySelector('.animOpacity').value) || 0;
      anim.scale = parseFloat(animDiv.querySelector('.animScale').value) || 1;
      updatePreviewAndCode();
      renderLayers();
    };

    animDiv.querySelectorAll('input').forEach(input => input.addEventListener('input', updateAnim));
    const lockExtra = animDiv.querySelector('.lockExtraAnim');
    if (lockExtra) lockExtra.addEventListener('change', updateAnim);

    animDiv.querySelector('.removeAnim').addEventListener('click', (ev) => {
      ev.stopPropagation();
      textData.extraAnims.splice(animIndex, 1);
      extraContainer.removeChild(animDiv);
      rebuildExtraAnimBlocks(wrapper, textData);
      updatePreviewAndCode();
      renderLayers();
    });

    updatePreviewAndCode();
    renderLayers();
  });
}

/* -------------------------------------------------------
   Utility to rebuild extra animation blocks (labels/ids) after a removal
--------------------------------------------------------- */
function rebuildExtraAnimBlocks(wrapper, imageData) {
  const extraContainer = wrapper.querySelector('.extra-anims');
  extraContainer.innerHTML = '';
  imageData.extraAnims.forEach((anim, ai) => {
    const animDiv = document.createElement('div');
    animDiv.classList.add('exit-controls');
    animDiv.innerHTML = `
      <strong>Extra Animation ${ai + 1}</strong><br />
      X: <input type="number" class="animX" value="${anim.x}" />
      Y: <input type="number" class="animY" value="${anim.y}" />
      Opacity: <input type="number" class="animOpacity" step="0.1" value="${anim.opacity}" />
      Scale: <input type="number" class="animScale" step="0.1" value="${anim.scale}" />
      Position (Time): <input type="number" class="animDelay" step="0.1" value="${anim.delay}" /> <br />
      <label><input type="checkbox" class="lockExtraAnim" ${anim.locked ? 'checked' : ''}> <i class="fa-solid fa-lock"></i> Lock Animation</label> <br />
      <button class="removeAnim">Remove</button>
    `;
    extraContainer.appendChild(animDiv);

    // attach handlers similar to createControlBlock's creation flow
    animDiv.addEventListener('click', (e) => {
      e.stopPropagation();
      activeDragTarget = { imgData: imageData, animIndex: ai };
      highlightPreview(imageData.id);
      highlightExtraAnim(wrapper, ai);
      updatePreviewAndCode();
      renderLayers();
    });

    const updateAnim = () => {
      anim.locked = !!animDiv.querySelector('.lockExtraAnim').checked;
      animDiv.querySelector('.animX').disabled = anim.locked;
      animDiv.querySelector('.animY').disabled = anim.locked;
      anim.delay = parseFloat(animDiv.querySelector('.animDelay').value) || 0;
      anim.x = parseFloat(animDiv.querySelector('.animX').value) || 0;
      anim.y = parseFloat(animDiv.querySelector('.animY').value) || 0;
      anim.opacity = parseFloat(animDiv.querySelector('.animOpacity').value) || 0;
      anim.scale = parseFloat(animDiv.querySelector('.animScale').value) || 1;
      updatePreviewAndCode();
      renderLayers();
    };

    animDiv.querySelectorAll('input').forEach(input => input.addEventListener('input', updateAnim));
    const lockExtra = animDiv.querySelector('.lockExtraAnim');
    if (lockExtra) lockExtra.addEventListener('change', updateAnim);
    animDiv.querySelector('.removeAnim').addEventListener('click', (ev) => {
      ev.stopPropagation();
      imageData.extraAnims.splice(ai, 1);
      rebuildExtraAnimBlocks(wrapper, imageData);
      updatePreviewAndCode();
      renderLayers();
    });
  });
}
/* -------------------------------------------------------
   Layers UI (REPLACEMENT renderLayers)
   - renderLayers() builds the tree UI from imageList[]
   - clicking nodes selects appropriate activeDragTarget
   - double-click layer name to inline edit id (fixed)
--------------------------------------------------------- */

/* -------------------------------------------------------
   Layers UI (REPLACEMENT renderLayers)
   - renderLayers() builds the tree UI from imageList[]
   - clicking nodes selects appropriate activeDragTarget
   - double-click layer name to inline edit id (fixed)
--------------------------------------------------------- */

function renderLayers() {
  const list = document.getElementById('layersList');
  if (!list) return;

  list.innerHTML = '';

  if (!imageList || imageList.length === 0) {
    const note = document.createElement('div');
    note.className = 'empty-note';
    note.textContent = 'No layers yet — add images to populate layers.';
    list.appendChild(note);
    return;
  }

  // helper: create a .layer-name node and attach dblclick rename handler
  function makeNameNode(img) {
    const name = document.createElement('div');
    name.className = 'layer-name';
    name.textContent = img.id;
    name.title = 'Double-click to rename id';

    name.addEventListener('dblclick', (ev) => {
      ev.stopPropagation();

      // Create input and replace name node
      const input = document.createElement('input');
      input.type = 'text';
      input.value = img.id;
      input.className = 'layer-name-edit';
      input.style.width = '100%';
      name.replaceWith(input);
      input.focus();
      input.select();

      // commit or cancel
      const commit = () => {
        let candidate = (input.value || '').trim();
        if (!candidate) candidate = img.id; // don't allow blank
        const sanitized = sanitizeId(candidate);
        const newId = (sanitized === img.id) ? img.id : ensureUniqueId(sanitized);

        // apply rename centrally
        const appliedId = setElementId(img, newId) || img.id;

        // restore name node
        const restored = makeNameNode(img); // recursive: will produce node with handler
        input.replaceWith(restored);

        // sync UI
        renderLayers();
        updatePreviewAndCode();
      };

      const cancel = () => {
        const restored = makeNameNode(img);
        input.replaceWith(restored);
      };

      input.addEventListener('keydown', (k) => {
        if (k.key === 'Enter') {
          input.blur(); // trigger commit on blur
        } else if (k.key === 'Escape') {
          cancel();
        }
      });

      // on blur commit (helps mobile/UX)
      input.addEventListener('blur', commit);
    });

    return name;
  }

  // iterate in reverse so topmost (last added) appears at top of list
  for (let i = imageList.length - 1; i >= 0; i--) {
    const img = imageList[i];

    const item = document.createElement('div');
    item.className = 'layer-item';
    item.dataset.imgId = img.id;

    // mark selected
    if (activeDragTarget && activeDragTarget.imgData === img && activeDragTarget.animIndex === null) {
      item.classList.add('selected', 'expanded');
    }

    const thumb = document.createElement('div');
    thumb.className = 'layer-thumb';
    if (img.type === 'image' && img.src) {
      const timg = document.createElement('img');
      timg.src = img.src;
      thumb.appendChild(timg);
    } else if (img.type === 'text') {
      const sample = document.createElement('div');
      sample.className = 'text-sample';
      sample.textContent = (img.text || 'Text').slice(0, 18);
      thumb.appendChild(sample);
    } else {
      thumb.textContent = '—';
      thumb.style.color = '#999';
      thumb.style.fontSize = '12px';
    }

    const info = document.createElement('div');
    info.className = 'layer-info';

    const nameNode = makeNameNode(img);
    const meta = document.createElement('div');
    meta.className = 'layer-meta';
    meta.textContent = `x:${img.x} y:${img.y} • ${img.width}px • delay ${img.delay}s`;

    info.appendChild(nameNode);
    info.appendChild(meta);

    const actions = document.createElement('div');
    actions.className = 'layer-actions';
    const chevron = document.createElement('i');
    chevron.className = 'fa-solid fa-chevron-down';
    actions.appendChild(chevron);

    item.appendChild(thumb);
    item.appendChild(info);
    item.appendChild(actions);

    // click on layer selects base image/text
    // IMPORTANT: ignore multi-clicks (detail > 1) so dblclick can work
    item.addEventListener('click', (e) => {
      if (e.detail > 1) return; // ignore second click of dblclick
      e.stopPropagation();
      activeDragTarget = { imgData: img, animIndex: null };
      highlightPreview(img.id);
      highlightExtraAnim(img.wrapper, null);
      updatePreviewAndCode();
      renderLayers();
      // scroll corresponding control into view
      try {
        img.wrapper.scrollIntoView({ behavior: 'smooth', block: 'center' });
        img.wrapper.classList.add('selected-control-flash');
        setTimeout(() => img.wrapper.classList.remove('selected-control-flash'), 600);
      } catch (err) {}
    });

    // sub-list for extra animations
    const animList = document.createElement('div');
    animList.className = 'anim-list';
    if (item.classList.contains('expanded')) animList.style.display = 'flex';

    img.extraAnims.forEach((anim, ai) => {
      const animRow = document.createElement('div');
      animRow.className = 'anim-item';
      animRow.dataset.imgId = img.id;
      animRow.dataset.animIndex = ai;

      // anim selected?
      if (activeDragTarget && activeDragTarget.imgData === img && activeDragTarget.animIndex === ai) {
        animRow.classList.add('selected');
        item.classList.add('expanded');
        animList.style.display = 'flex';
      }

      const animLabel = document.createElement('div');
      animLabel.className = 'anim-label';
      animLabel.textContent = `Extra ${ai + 1}`;

      const animMeta = document.createElement('div');
      animMeta.className = 'anim-meta';
      animMeta.textContent = `x:${anim.x} y:${anim.y} • delay ${anim.delay}s`;

      animRow.appendChild(animLabel);
      animRow.appendChild(animMeta);

      animRow.addEventListener('click', (e) => {
        e.stopPropagation();
        activeDragTarget = { imgData: img, animIndex: ai };
        highlightPreview(img.id);
        highlightExtraAnim(img.wrapper, ai);
        updatePreviewAndCode();
        renderLayers();

        // scroll to control and highlight the specific anim block
        try {
          img.wrapper.scrollIntoView({ behavior: 'smooth', block: 'center' });
          const animDiv = img.wrapper.querySelectorAll('.extra-anims .exit-controls')[ai];
          if (animDiv) {
            animDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
            animDiv.classList.add('selected');
            setTimeout(() => animDiv.classList.remove('selected'), 700);
          }
        } catch (err) {}
      });

      animList.appendChild(animRow);
    });

    list.appendChild(item);
    list.appendChild(animList);
  }
}



/* Expand / Collapse All buttons wiring */
const expandBtn = document.getElementById('expandAllLayers');
const collapseBtn = document.getElementById('collapseAllLayers');
if (expandBtn) expandBtn.addEventListener('click', () => {
  document.querySelectorAll('.layer-item').forEach(li => li.classList.add('expanded'));
  document.querySelectorAll('.anim-list').forEach(al => al.style.display = 'flex');
});
if (collapseBtn) collapseBtn.addEventListener('click', () => {
  document.querySelectorAll('.layer-item').forEach(li => li.classList.remove('expanded'));
  document.querySelectorAll('.anim-list').forEach(al => al.style.display = 'none');
});

/* "Add Image" button logic (keeps original behavior) */
const addImageBtn = document.getElementById('addImageBtn');
if (addImageBtn) {
  addImageBtn.addEventListener('click', () => {
    // Lock all previous images + animations
    imageList.forEach(prevImg => {
      prevImg.locked = true;
      const wrapper = prevImg.wrapper;
      const lockBox = wrapper.querySelector('.lockPosition');
      if (lockBox) lockBox.checked = true;
      const posX = wrapper.querySelector('.posX');
      const posY = wrapper.querySelector('.posY');
      if (posX) posX.disabled = true;
      if (posY) posY.disabled = true;

      prevImg.extraAnims.forEach((anim, i) => {
        anim.locked = true;
        const animDiv = wrapper.querySelectorAll('.extra-anims .exit-controls')[i];
        if (animDiv) {
          const lockBox2 = animDiv.querySelector('.lockExtraAnim');
          const xInput = animDiv.querySelector('.animX');
          const yInput = animDiv.querySelector('.animY');
          if (lockBox2) lockBox2.checked = true;
          if (xInput) xInput.disabled = true;
          if (yInput) yInput.disabled = true;
        }
      });
    });

    // Add new image block
    createControlBlock(imageList.length);
    // Re-render layers to include the new item
    renderLayers();
  });
}

/* "Add Text" button logic */
const addTextBtn = document.getElementById('addTextBtn');
if (addTextBtn) {
  addTextBtn.addEventListener('click', () => {
    // Lock all previous elements + animations
    imageList.forEach(prev => {
      prev.locked = true;
      const wrapper = prev.wrapper;
      const lockBox = wrapper.querySelector('.lockPosition');
      if (lockBox) lockBox.checked = true;
      const posX = wrapper.querySelector('.posX');
      const posY = wrapper.querySelector('.posY');
      if (posX) posX.disabled = true;
      if (posY) posY.disabled = true;

      prev.extraAnims.forEach((anim, i) => {
        anim.locked = true;
        const animDiv = wrapper.querySelectorAll('.extra-anims .exit-controls')[i];
        if (animDiv) {
          const lockBox2 = animDiv.querySelector('.lockExtraAnim');
          const xInput = animDiv.querySelector('.animX');
          const yInput = animDiv.querySelector('.animY');
          if (lockBox2) lockBox2.checked = true;
          if (xInput) xInput.disabled = true;
          if (yInput) yInput.disabled = true;
        }
      });
    });

    // Add new text block
    createTextControlBlock(imageList.length);
    renderLayers();
  });
}

/* Ensure renderLayers is called on load to reflect any existing images */
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    try { renderLayers(); } catch (e) {}
  }, 50);
});
